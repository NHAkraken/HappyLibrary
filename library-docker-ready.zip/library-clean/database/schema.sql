-- Library Management System — database schema
-- Import this via phpMyAdmin on your InfinityFree MySQL database.

CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    isbn VARCHAR(50) DEFAULT NULL,
    category VARCHAR(100) DEFAULT 'Other',
    year INT DEFAULT NULL,
    quantity INT NOT NULL DEFAULT 1,
    available INT NOT NULL DEFAULT 1,
    image VARCHAR(255) DEFAULT 'default.jpg',
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS borrowed_books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT NOT NULL,
    student_name VARCHAR(150) NOT NULL,
    student_id VARCHAR(50) NOT NULL,
    borrow_date DATE NOT NULL,
    return_date DATE NOT NULL,
    actual_return_date DATE DEFAULT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'borrowed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);

-- Default admin login: username "admin", password "admin123"
-- The password hash below was generated with PHP's password_hash() (bcrypt).
-- CHANGE THIS PASSWORD after your first login.
INSERT INTO users (username, password, full_name)
VALUES ('admin', '$2b$10$ZGnitlKXmr2jsoAecjjUS.cCQVk29s8a4PkdetE61RuNCN.iYOBke', 'Administrator');
