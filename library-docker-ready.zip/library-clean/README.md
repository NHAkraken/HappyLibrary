# Library Management System

## What changed vs the original zip

The original was a flat PHP dump with `config.php` sitting right next to
`index.php` in the web root, hardcoded DB credentials, and no way to run it
locally without a full cPanel-style host. Fixed for a real dev workflow:

```
library/
├── public/              <- Apache document root (only this is web-accessible)
│   ├── index.php
│   ├── admin/
│   └── images/books/
├── src/
│   └── config.php        <- DB class, NOT web-accessible, reads env vars
├── database/
│   └── schema.sql
├── docker/
│   └── 000-default.conf  <- Apache vhost, DocumentRoot -> public/
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── .gitignore
```

Why this matters:
- `src/config.php` is outside `public/`, so it can never be served directly
  even if Apache is misconfigured (the vhost also explicitly denies it).
- DB credentials come from environment variables (`DB_HOST`, `DB_NAME`,
  `DB_USER`, `DB_PASS`) instead of being hardcoded — same code works for
  local Docker, staging, or any host, you just change env vars.
- Uploaded book cover images live in a Docker volume so they survive
  container rebuilds.

All the `require`/`include` paths in `index.php` and `admin/*.php` were
updated to match (`../src/config.php` and `../../src/config.php`
respectively). No logic was changed.

## Run it

```bash
cp .env.example .env      # edit if you want different creds
docker compose up -d --build
```

- App: http://localhost:8080
- phpMyAdmin: http://localhost:8081 (server: `db`, user/pass from `.env`)
- Login: `admin` / `admin123` (change this after first login)

The `db` service auto-imports `database/schema.sql` on first run (creates
`users`, `books`, `borrowed_books` tables + the default admin user).

## Still worth doing (not done here, since it touches app logic)

- `index.php` accepts plain-text password OR bcrypt (`$password === $user['password'] || password_verify(...)`)
  — drop the plain-text branch once you've confirmed the admin row uses a
  bcrypt hash.
- `save_book.php` / `update_book.php` trust the client's `accept="image/*"`
  hint only — add real server-side MIME/extension checks before accepting
  uploads from untrusted users.
- `admin/auth.php`, `admin/book.php`, `admin/borrow.php` are legacy/unused
  (dashboard.php doesn't call them) — safe to delete once you confirm
  nothing references them.
