<?php
session_start();
header('Content-Type: application/json');

// Check if user is logged in
if(!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once __DIR__ . '/../../src/config.php';

$database = new Database();
$db = $database->getConnection();

$action = isset($_GET['action']) ? $_GET['action'] : '';

// Get all books
if($action == 'getAll') {
    try {
        $query = "SELECT * FROM books ORDER BY created_at DESC";
        $stmt = $db->prepare($query);
        $stmt->execute();
        
        $books = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['success' => true, 'books' => $books]);
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}

// Add book
if($action == 'add') {
    try {
        $title = $_POST['title'] ?? '';
        $author = $_POST['author'] ?? '';
        $isbn = $_POST['isbn'] ?? '';
        $category = $_POST['category'] ?? '';
        $year = $_POST['year'] ?? null;
        $quantity = $_POST['quantity'] ?? 1;
        $image = $_POST['image'] ?? 'https://via.placeholder.com/280x400/667eea/ffffff?text=No+Cover';
        $description = $_POST['description'] ?? '';
        
        // Validate required fields
        if(empty($title) || empty($author) || empty($isbn) || empty($category)) {
            echo json_encode(['success' => false, 'message' => 'Please fill all required fields']);
            exit();
        }
        
        $query = "INSERT INTO books (title, author, isbn, category, year, quantity, available, image, description) 
                  VALUES (:title, :author, :isbn, :category, :year, :quantity, :quantity, :image, :description)";
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':author', $author);
        $stmt->bindParam(':isbn', $isbn);
        $stmt->bindParam(':category', $category);
        $stmt->bindParam(':year', $year);
        $stmt->bindParam(':quantity', $quantity);
        $stmt->bindParam(':image', $image);
        $stmt->bindParam(':description', $description);
        
        if($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Book added successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to add book']);
        }
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
}

// Update book
if($action == 'update') {
    try {
        $id = $_POST['id'] ?? '';
        $title = $_POST['title'] ?? '';
        $author = $_POST['author'] ?? '';
        $isbn = $_POST['isbn'] ?? '';
        $category = $_POST['category'] ?? '';
        $year = $_POST['year'] ?? null;
        $quantity = $_POST['quantity'] ?? 1;
        $image = $_POST['image'] ?? '';
        $description = $_POST['description'] ?? '';
        
        // Get current available count
        $query = "SELECT quantity, available FROM books WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $current = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if(!$current) {
            echo json_encode(['success' => false, 'message' => 'Book not found']);
            exit();
        }
        
        $new_available = $current['available'] + ($quantity - $current['quantity']);
        
        $query = "UPDATE books SET title = :title, author = :author, isbn = :isbn, category = :category, 
                  year = :year, quantity = :quantity, available = :available, image = :image, description = :description 
                  WHERE id = :id";
        
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':author', $author);
        $stmt->bindParam(':isbn', $isbn);
        $stmt->bindParam(':category', $category);
        $stmt->bindParam(':year', $year);
        $stmt->bindParam(':quantity', $quantity);
        $stmt->bindParam(':available', $new_available);
        $stmt->bindParam(':image', $image);
        $stmt->bindParam(':description', $description);
        
        if($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Book updated successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to update book']);
        }
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
}

// Delete book
if($action == 'delete') {
    try {
        $id = $_GET['id'] ?? '';
        
        // Check if book is borrowed
        $query = "SELECT COUNT(*) as count FROM borrowed_books WHERE book_id = :id AND status = 'borrowed'";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if($result['count'] > 0) {
            echo json_encode(['success' => false, 'message' => 'Cannot delete! Book is currently borrowed']);
            exit();
        }
        
        $query = "DELETE FROM books WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $id);
        
        if($stmt->execute()) {
            echo json_encode(['success' => true, 'message' => 'Book deleted successfully']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to delete book']);
        }
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
}

// Get statistics
if($action == 'stats') {
    try {
        $stats = [];
        
        // Total books
        $query = "SELECT COUNT(*) as total, SUM(available) as available FROM books";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $stats['books'] = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Borrowed count
        $query = "SELECT COUNT(*) as count FROM borrowed_books WHERE status = 'borrowed'";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $stats['borrowed'] = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        // Category stats
        $query = "SELECT category, COUNT(*) as count FROM books GROUP BY category";
        $stmt = $db->prepare($query);
        $stmt->execute();
        $stats['categories'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode(['success' => true, 'stats' => $stats]);
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
    }
}
?>