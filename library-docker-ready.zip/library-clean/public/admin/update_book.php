<?php
session_start();

if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$folder = "../images/books/";

$id          = isset($_POST['txtid']) ? $_POST['txtid'] : '';
$title       = isset($_POST['txtname']) ? $_POST['txtname'] : '';
$author      = isset($_POST['txtauthor']) ? $_POST['txtauthor'] : '';
$isbn        = isset($_POST['txtisbn']) ? $_POST['txtisbn'] : '';
$category    = isset($_POST['txtcategory']) ? $_POST['txtcategory'] : '';
$year        = isset($_POST['txtyear']) ? $_POST['txtyear'] : NULL;
$quantity    = isset($_POST['txtquantity']) ? $_POST['txtquantity'] : 1;
$description = isset($_POST['txtdescription']) ? $_POST['txtdescription'] : '';
$old_image   = isset($_POST['old_image']) ? $_POST['old_image'] : '';

// Handle new image upload
$img = $old_image;
if (isset($_FILES['files']) && $_FILES['files']['error'] == 0) {
    // Delete old image
    if($old_image && file_exists($folder . $old_image)) {
        unlink($folder . $old_image);
    }
    
    // Upload new image
    $img = time() . '_' . $_FILES['files']['name'];
    move_uploaded_file($_FILES['files']['tmp_name'], $folder . $img);
}

include_once(__DIR__ . '/../../src/config.php');

$database = new Database();
$conn = $database->getConnection();

// Get current quantity to calculate available
$stmt = $conn->prepare("SELECT quantity, available FROM books WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$current = $stmt->fetch(PDO::FETCH_ASSOC);

$new_available = $current['available'] + ($quantity - $current['quantity']);

$stmt = $conn->prepare("UPDATE books 
                        SET title = :title, 
                            author = :author, 
                            isbn = :isbn, 
                            category = :category, 
                            year = :year, 
                            quantity = :quantity, 
                            available = :available, 
                            image = :image, 
                            description = :description 
                        WHERE id = :id");

$stmt->bindParam(':id', $id);
$stmt->bindParam(':title', $title);
$stmt->bindParam(':author', $author);
$stmt->bindParam(':isbn', $isbn);
$stmt->bindParam(':category', $category);
$stmt->bindParam(':year', $year);
$stmt->bindParam(':quantity', $quantity);
$stmt->bindParam(':available', $new_available);
$stmt->bindParam(':image', $img);
$stmt->bindParam(':description', $description);

if ($stmt->execute()) {
    echo "<script>
            alert('Book updated successfully!');
            window.location.href='dashboard.php';
          </script>";
} else {
    echo "<script>
            alert('Could not update book!');
            window.history.back();
          </script>";
}
?>