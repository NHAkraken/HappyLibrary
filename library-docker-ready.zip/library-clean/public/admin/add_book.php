<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Book - Library System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); font-family: Arial, sans-serif;">

    <div class="container" style="max-width: 800px; margin: 50px auto; background: white; padding: 40px; border-radius: 15px;">
        <a href="dashboard.php" style="color: #2196F3; text-decoration: none;">
            <i class="fas fa-arrow-left"></i> Back to List
        </a>

        <div style="text-align: center; margin: 20px 0;">
            <h2><i class="fas fa-plus-circle"></i> Add New Book</h2>
        </div>

        <form action="save_book.php" method="POST" enctype="multipart/form-data">

            <div style="text-align: center; margin: 20px 0;">
                <img id="preview"
                     src="https://via.placeholder.com/200x280?text=Book+Cover"
                     alt="Book Cover"
                     style="max-width: 200px; border: 2px dashed #ddd; border-radius: 10px; padding: 10px;">
            </div>

            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                    <i class="fas fa-image"></i> Book Cover
                </label>
                <input type="file" name="files" accept="image/*" onchange="previewImage(event)">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                        <i class="fas fa-book"></i> Book Title *
                    </label>
                    <input type="text" name="txtname"
                           style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px;" required>
                </div>

                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                        <i class="fas fa-user"></i> Author *
                    </label>
                    <input type="text" name="txtauthor"
                           style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px;" required>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                        <i class="fas fa-barcode"></i> ISBN *
                    </label>
                    <input type="text" name="txtisbn"
                           style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px;" required>
                </div>

                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                        <i class="fas fa-tags"></i> Category *
                    </label>
                    <select name="txtcategory" style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px;" required>
                        <option value="">Select Category</option>
                        <?php
                        $categories = ['Fiction', 'Non-Fiction', 'Science', 'History', 'Technology', 'Art', 'Biography', 'Children', 'Other'];
                        foreach($categories as $cat): ?>
                            <option value="<?php echo $cat; ?>"><?php echo $cat; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                        <i class="fas fa-calendar"></i> Year
                    </label>
                    <input type="number" name="txtyear"
                           style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px;">
                </div>

                <div>
                    <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                        <i class="fas fa-box"></i> Quantity *
                    </label>
                    <input type="number" name="txtquantity" value="1" min="1"
                           style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px;" required>
                </div>
            </div>

            <div style="margin-bottom: 20px;">
                <label style="display: block; margin-bottom: 8px; font-weight: 600;">
                    <i class="fas fa-align-left"></i> Description
                </label>
                <textarea name="txtdescription" rows="4"
                          style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px;"></textarea>
            </div>

            <div style="text-align: center; margin-top: 30px;">
                <button type="submit" style="padding: 12px 30px; background: #2196F3; color: white; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: 600;">
                    <i class="fas fa-save"></i> Add Book
                </button>
            </div>
        </form>
    </div>

    <script>
        function previewImage(event) {
            const file = event.target.files[0];
            const preview = document.getElementById('preview');
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                }
                reader.readAsDataURL(file);
            }
        }
    </script>

</body>
</html>
