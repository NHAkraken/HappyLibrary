<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

require_once __DIR__ . '/../../src/config.php';
$conn = (new Database())->getConnection();

// Get all books
$stmt = $conn->prepare("SELECT * FROM books ORDER BY id DESC");
$stmt->execute();
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get borrowed books
$stmt_borrowed = $conn->prepare("SELECT bb.*, b.title, b.image, b.author 
                                 FROM borrowed_books bb 
                                 JOIN books b ON bb.book_id = b.id 
                                 WHERE bb.status = 'borrowed' 
                                 ORDER BY bb.created_at DESC");
$stmt_borrowed->execute();
$borrowed_books = $stmt_borrowed->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$total_books = count($books);
$available = array_sum(array_column($books, 'available'));
$borrowed_count = count($borrowed_books);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }

        .container { max-width: 1400px; margin: auto; }

        /* Header */
        .header {
            background: white;
            padding: 25px 35px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.15);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header h1 {
            color: #333;
            font-size: 32px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .header h1 i { color: #667eea; }

        .header-actions {
            display: flex;
            gap: 12px;
        }

        .btn {
            padding: 12px 25px;
            color: white;
            text-decoration: none;
            border-radius: 10px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
        }

        .btn-primary { background: linear-gradient(135deg, #2196F3, #1976D2); }
        .btn-success { background: linear-gradient(135deg, #4CAF50, #45a049); }
        .btn-danger { background: linear-gradient(135deg, #f44336, #d32f2f); }
        .btn-warning { background: linear-gradient(135deg, #FF9800, #F57C00); }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.3); }

        /* Success Message */
        .success {
            background: linear-gradient(135deg, #4CAF50, #45a049);
            color: white;
            padding: 18px 25px;
            border-radius: 12px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
            font-weight: 600;
            box-shadow: 0 4px 15px rgba(76, 175, 80, 0.3);
            animation: slideDown 0.5s;
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Statistics Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 20px;
            transition: transform 0.3s;
        }

        .stat-card:hover { transform: translateY(-5px); }

        .stat-icon {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: white;
        }

        .stat-icon.green { background: linear-gradient(135deg, #4CAF50, #45a049); }
        .stat-icon.blue { background: linear-gradient(135deg, #2196F3, #1976D2); }
        .stat-icon.orange { background: linear-gradient(135deg, #FF9800, #F57C00); }

        .stat-info h3 {
            font-size: 36px;
            color: #333;
            margin-bottom: 5px;
        }

        .stat-info p {
            color: #666;
            font-size: 15px;
        }

        /* Navigation Tabs */
        .tabs {
            background: white;
            padding: 10px;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 25px;
            display: flex;
            gap: 10px;
        }

        .tab-btn {
            flex: 1;
            padding: 15px;
            background: transparent;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            color: #666;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .tab-btn.active {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            box-shadow: 0 4px 15px rgba(102, 126, 234, 0.4);
        }

        .tab-btn:hover:not(.active) {
            background: #f0f0f0;
        }

        /* Tab Content */
        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
            animation: fadeIn 0.4s;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Books Grid */
        .books-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 25px;
        }

        .book-card {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }

        .book-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }

        .book-card img {
            width: 100%;
            height: 350px;
            object-fit: cover;
        }

        .book-card-body {
            padding: 20px;
        }

        .book-title {
            font-size: 18px;
            font-weight: 700;
            color: #333;
            margin-bottom: 8px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .book-author {
            color: #666;
            font-size: 14px;
            margin-bottom: 12px;
        }

        .book-meta {
            display: flex;
            gap: 15px;
            margin: 10px 0;
            font-size: 13px;
            color: #777;
        }

        .book-category {
            display: inline-block;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 5px 12px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
        }

        .book-status {
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 600;
            margin: 10px 0;
            display: inline-block;
        }

        .available { background: #e8f5e9; color: #2e7d32; }
        .unavailable { background: #ffebee; color: #c62828; }

        .book-actions {
            display: flex;
            gap: 8px;
            margin-top: 15px;
        }

        .btn-sm {
            padding: 8px 15px;
            font-size: 13px;
            flex: 1;
        }

        /* Table */
        .table-container {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 18px;
            text-align: left;
            font-weight: 600;
        }

        td {
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
        }

        tr:hover {
            background: #f8f9fa;
        }

        .book-thumb {
            width: 70px;
            height: 90px;
            object-fit: cover;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
        }

        /* Borrowed Books */
        .borrowed-item {
            background: white;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 15px;
            display: grid;
            grid-template-columns: auto 1fr auto;
            gap: 20px;
            align-items: center;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }

        .borrowed-item:hover {
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
            transform: translateX(5px);
        }

        .borrowed-img {
            width: 80px;
            height: 110px;
            object-fit: cover;
            border-radius: 8px;
        }

        .borrowed-details h4 {
            color: #333;
            margin-bottom: 8px;
            font-size: 18px;
        }

        .borrowed-details p {
            color: #666;
            margin: 5px 0;
            font-size: 14px;
        }

        .overdue {
            color: #f44336;
            font-weight: 700;
        }

        /* Empty State */
        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #999;
        }

        .empty-state i {
            font-size: 80px;
            margin-bottom: 20px;
            opacity: 0.3;
        }

        .empty-state h3 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        /* Modal */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.6);
            backdrop-filter: blur(5px);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal.active { display: flex; }

        .modal-content {
            background: white;
            border-radius: 15px;
            width: 90%;
            max-width: 500px;
            padding: 30px;
            animation: slideUp 0.3s;
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(50px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .modal-header h2 {
            color: #333;
            font-size: 24px;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: 28px;
            cursor: pointer;
            color: #999;
        }

        .close-modal:hover { color: #f44336; }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-weight: 600;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 15px;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
        }

        .modal-actions {
            display: flex;
            gap: 12px;
            margin-top: 25px;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .header { flex-direction: column; gap: 15px; }
            .stats-grid { grid-template-columns: 1fr; }
            .books-grid { grid-template-columns: 1fr; }
            .borrowed-item { grid-template-columns: 1fr; }
            .tabs { flex-direction: column; }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header -->
    <div class="header">
        <h1><i class="fas fa-book-reader"></i> Library Dashboard</h1>
        <div class="header-actions">
            <a href="add_book.php" class="btn btn-success">
                <i class="fas fa-plus"></i> Add Book
            </a>
            <span style="color:#666; padding:12px;">👤 <?php echo $_SESSION['username']; ?></span>
            <a href="logout.php" class="btn btn-danger">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>

    <!-- Success Message -->
    <?php if(isset($_SESSION['success'])): ?>
        <div class="success">
            <i class="fas fa-check-circle" style="font-size:24px;"></i>
            <span><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></span>
        </div>
    <?php endif; ?>

    <!-- Statistics Cards -->
    <div class="stats-grid">
        <div class="stat-card">
            <div class="stat-icon green">
                <i class="fas fa-book"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $total_books; ?></h3>
                <p>Total Books</p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon blue">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $available; ?></h3>
                <p>Available</p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon orange">
                <i class="fas fa-hand-holding"></i>
            </div>
            <div class="stat-info">
                <h3><?php echo $borrowed_count; ?></h3>
                <p>Borrowed</p>
            </div>
        </div>
    </div>

    <!-- Navigation Tabs -->
    <div class="tabs">
        <button class="tab-btn active" onclick="openTab('allBooks')">
            <i class="fas fa-book"></i> All Books
        </button>
        <button class="tab-btn" onclick="openTab('borrowedBooks')">
            <i class="fas fa-hand-holding"></i> Borrowed Books
        </button>
        <button class="tab-btn" onclick="openTab('manageBooks')">
            <i class="fas fa-cog"></i> Manage Books
        </button>
    </div>

    <!-- Tab 1: All Books (Grid View) -->
    <div id="allBooks" class="tab-content active">
        <?php if(empty($books)): ?>
            <div class="empty-state">
                <i class="fas fa-book"></i>
                <h3>No Books Yet</h3>
                <p>Add your first book to get started</p>
                <a href="add_book.php" class="btn btn-success" style="margin-top:20px;">Add Book</a>
            </div>
        <?php else: ?>
            <div class="books-grid">
                <?php foreach($books as $book): ?>
                    <div class="book-card">
                        <img src="../images/books/<?php echo htmlspecialchars($book['image']); ?>" 
                             alt="<?php echo htmlspecialchars($book['title']); ?>"
                             onerror="this.src='https://via.placeholder.com/280x350/667eea/ffffff?text=<?php echo urlencode($book['title']); ?>'">
                        <div class="book-card-body">
                            <div class="book-title"><?php echo htmlspecialchars($book['title']); ?></div>
                            <div class="book-author">by <?php echo htmlspecialchars($book['author']); ?></div>
                            <div class="book-meta">
                                <span><i class="fas fa-barcode"></i> <?php echo $book['isbn']; ?></span>
                            </div>
                            <span class="book-category"><?php echo $book['category']; ?></span>
                            <div class="book-status <?php echo $book['available'] > 0 ? 'available' : 'unavailable'; ?>">
                                <?php echo $book['available']; ?> / <?php echo $book['quantity']; ?> Available
                            </div>
                            <div class="book-actions">
                                <?php if($book['available'] > 0): ?>
                                    <button class="btn btn-success btn-sm" onclick="openBorrowModal(<?php echo $book['id']; ?>, '<?php echo htmlspecialchars($book['title']); ?>')">
                                        <i class="fas fa-hand-holding"></i> Borrow
                                    </button>
                                <?php endif; ?>
                                <a href="edit_book.php?id=<?php echo $book['id']; ?>" class="btn btn-primary btn-sm">
                                    <i class="fas fa-edit"></i> Edit
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- Tab 2: Borrowed Books -->
    <div id="borrowedBooks" class="tab-content">
        <?php if(empty($borrowed_books)): ?>
            <div class="empty-state">
                <i class="fas fa-hand-holding"></i>
                <h3>No Borrowed Books</h3>
                <p>All books are currently available</p>
            </div>
        <?php else: ?>
            <?php foreach($borrowed_books as $borrow): ?>
                <div class="borrowed-item">
                    <img src="../images/books/<?php echo htmlspecialchars($borrow['image']); ?>" 
                         class="borrowed-img"
                         onerror="this.src='https://via.placeholder.com/80x110'">
                    <div class="borrowed-details">
                        <h4><?php echo htmlspecialchars($borrow['title']); ?></h4>
                        <p><strong>Student:</strong> <?php echo htmlspecialchars($borrow['student_name']); ?></p>
                        <p><strong>Student ID:</strong> <?php echo htmlspecialchars($borrow['student_id']); ?></p>
                        <p><strong>Borrowed:</strong> <?php echo $borrow['borrow_date']; ?></p>
                        <p class="<?php echo (strtotime($borrow['return_date']) < time()) ? 'overdue' : ''; ?>">
                            <strong>Return by:</strong> <?php echo $borrow['return_date']; ?>
                            <?php if(strtotime($borrow['return_date']) < time()): ?>
                                ⚠️ OVERDUE
                            <?php endif; ?>
                        </p>
                    </div>
                    <button class="btn btn-success" onclick="returnBook(<?php echo $borrow['id']; ?>)">
                        <i class="fas fa-check"></i> Return Book
                    </button>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Tab 3: Manage Books (Table View) -->
    <div id="manageBooks" class="tab-content">
        <?php if(empty($books)): ?>
            <div class="empty-state">
                <i class="fas fa-cog"></i>
                <h3>No Books to Manage</h3>
            </div>
        <?php else: ?>
            <div class="table-container">
                <table>
                    <tr>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>ISBN</th>
                        <th>Category</th>
                        <th>Quantity</th>
                        <th>Available</th>
                        <th>Actions</th>
                    </tr>
                    <?php foreach($books as $book): ?>
                    <tr>
                        <td>
                            <img src="../images/books/<?php echo htmlspecialchars($book['image']); ?>" 
                                 class="book-thumb"
                                 onerror="this.src='https://via.placeholder.com/70x90'">
                        </td>
                        <td><strong><?php echo htmlspecialchars($book['title']); ?></strong></td>
                        <td><?php echo htmlspecialchars($book['author']); ?></td>
                        <td><?php echo htmlspecialchars($book['isbn']); ?></td>
                        <td><?php echo htmlspecialchars($book['category']); ?></td>
                        <td><?php echo $book['quantity']; ?></td>
                        <td>
                            <span class="book-status <?php echo $book['available'] > 0 ? 'available' : 'unavailable'; ?>">
                                <?php echo $book['available']; ?>
                            </span>
                        </td>
                        <td>
                            <a href="edit_book.php?id=<?php echo $book['id']; ?>" class="btn btn-primary btn-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button onclick="deleteBook(<?php echo $book['id']; ?>)" class="btn btn-danger btn-sm">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Borrow Modal -->
<div id="borrowModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2><i class="fas fa-hand-holding"></i> Borrow Book</h2>
            <button class="close-modal" onclick="closeBorrowModal()">&times;</button>
        </div>
        <form action="borrow_handler.php" method="POST">
            <div class="form-group">
                <label>Book Title</label>
                <input type="text" id="bookTitleDisplay" readonly style="background:#f0f0f0;">
            </div>
            <div class="form-group">
                <label>Student Name *</label>
                <input type="text" name="student_name" required>
            </div>
            <div class="form-group">
                <label>Student ID *</label>
                <input type="text" name="student_id" required>
            </div>
            <div class="form-group">
                <label>Borrow Date *</label>
                <input type="date" name="borrow_date" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="form-group">
                <label>Return Date *</label>
                <input type="date" name="return_date" value="<?php echo date('Y-m-d', strtotime('+14 days')); ?>" required>
            </div>
            <input type="hidden" name="book_id" id="borrowBookId">
            <div class="modal-actions">
                <button type="button" class="btn btn-danger" onclick="closeBorrowModal()">Cancel</button>
                <button type="submit" class="btn btn-success">Confirm Borrow</button>
            </div>
        </form>
    </div>
</div>

<script>
    // Tab Switching
    function openTab(tabName) {
        const tabs = document.querySelectorAll('.tab-content');
        const btns = document.querySelectorAll('.tab-btn');
        
        tabs.forEach(tab => tab.classList.remove('active'));
        btns.forEach(btn => btn.classList.remove('active'));
        
        document.getElementById(tabName).classList.add('active');
        event.target.classList.add('active');
    }

    // Borrow Modal
    function openBorrowModal(bookId, bookTitle) {
        document.getElementById('borrowBookId').value = bookId;
        document.getElementById('bookTitleDisplay').value = bookTitle;
        document.getElementById('borrowModal').classList.add('active');
    }

    function closeBorrowModal() {
        document.getElementById('borrowModal').classList.remove('active');
    }

    // Return Book
    function returnBook(borrowId) {
        if(confirm('Mark this book as returned?')) {
            window.location.href = 'return_book.php?id=' + borrowId;
        }
    }

    // Delete Book
    function deleteBook(bookId) {
        if(confirm('⚠️ Are you sure you want to delete this book?')) {
            window.location.href = 'delete_book.php?id=' + bookId;
        }
    }

    // Close modal on outside click
    window.onclick = function(event) {
        const modal = document.getElementById('borrowModal');
        if (event.target == modal) {
            closeBorrowModal();
        }
    }

    // Auto-hide success message
    setTimeout(() => {
        const success = document.querySelector('.success');
        if(success) {
            success.style.animation = 'slideDown 0.5s reverse';
            setTimeout(() => success.remove(), 500);
        }
    }, 5000);
</script>

</body>
</html>