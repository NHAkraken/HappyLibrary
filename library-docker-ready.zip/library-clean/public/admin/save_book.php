<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$folder = "../images/books/";
if (!file_exists($folder)) {
    mkdir($folder, 0777, true);
}

$title    = $_POST['txtname'] ?? '';
$author   = $_POST['txtauthor'] ?? '';
$isbn     = $_POST['txtisbn'] ?? '';
$category = $_POST['txtcategory'] ?? 'Other';
$year     = $_POST['txtyear'] ?? null;
$quantity = $_POST['txtquantity'] ?? 1;
$desc     = $_POST['txtdescription'] ?? '';

$image = 'default.jpg';
if(isset($_FILES['files']) && $_FILES['files']['error'] == 0) {
    $image = time() . '_' . $_FILES['files']['name'];
    move_uploaded_file($_FILES['files']['tmp_name'], $folder . $image);
}

require_once __DIR__ . '/../../src/config.php';
$conn = (new Database())->getConnection();

$stmt = $conn->prepare("INSERT INTO books 
    (title, author, isbn, category, year, quantity, available, image, description) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->execute([$title, $author, $isbn, $category, $year, $quantity, $quantity, $image, $desc]);

$_SESSION['success'] = "Book added successfully!";
header("Location: dashboard.php");
exit();
?>