<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

require_once __DIR__ . '/../../src/config.php';
$conn = (new Database())->getConnection();

$borrow_id = $_GET['id'];

// Get book_id
$get_book = $conn->prepare("SELECT book_id FROM borrowed_books WHERE id = ?");
$get_book->execute([$borrow_id]);
$borrow = $get_book->fetch();

// Update borrow status
$stmt = $conn->prepare("UPDATE borrowed_books SET status = 'returned', actual_return_date = CURDATE() WHERE id = ?");
$stmt->execute([$borrow_id]);

// Update book availability
$update = $conn->prepare("UPDATE books SET available = available + 1 WHERE id = ?");
$update->execute([$borrow['book_id']]);

$_SESSION['success'] = "Book returned successfully!";
header("Location: dashboard.php");
exit();
?>