<?php
session_start();
header('Content-Type: application/json');

if(!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once __DIR__ . '/../../src/config.php';

$database = new Database();
$db = $database->getConnection();

$action = isset($_GET['action']) ? $_GET['action'] : '';

// Get all borrowed books
if($action == 'getAll') {
    $query = "SELECT bb.*, b.title, b.image 
              FROM borrowed_books bb 
              JOIN books b ON bb.book_id = b.id 
              WHERE bb.status = 'borrowed'
              ORDER BY bb.created_at DESC";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $borrowed = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'borrowed' => $borrowed]);
}

// Borrow book
if($action == 'borrow') {
    $book_id = $_POST['book_id'] ?? '';
    $student_name = $_POST['student_name'] ?? '';
    $student_id = $_POST['student_id'] ?? '';
    $borrow_date = $_POST['borrow_date'] ?? '';
    $return_date = $_POST['return_date'] ?? '';
    
    $query = "SELECT available FROM books WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $book_id);
    $stmt->execute();
    $book = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($book['available'] <= 0) {
        echo json_encode(['success' => false, 'message' => 'Book not available']);
        exit();
    }
    
    $query = "INSERT INTO borrowed_books (book_id, student_name, student_id, borrow_date, return_date) 
              VALUES (:book_id, :student_name, :student_id, :borrow_date, :return_date)";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':book_id', $book_id);
    $stmt->bindParam(':student_name', $student_name);
    $stmt->bindParam(':student_id', $student_id);
    $stmt->bindParam(':borrow_date', $borrow_date);
    $stmt->bindParam(':return_date', $return_date);
    
    if($stmt->execute()) {
        $query = "UPDATE books SET available = available - 1 WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $book_id);
        $stmt->execute();
        
        echo json_encode(['success' => true, 'message' => 'Book borrowed successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to borrow book']);
    }
}

// Return book
if($action == 'return') {
    $id = $_POST['id'] ?? '';
    
    $query = "SELECT book_id FROM borrowed_books WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $borrow = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $query = "UPDATE borrowed_books SET status = 'returned', actual_return_date = CURDATE() WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    
    if($stmt->execute()) {
        $query = "UPDATE books SET available = available + 1 WHERE id = :book_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':book_id', $borrow['book_id']);
        $stmt->execute();
        
        echo json_encode(['success' => true, 'message' => 'Book returned successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to return book']);
    }
}

// Get activity log
if($action == 'activity') {
    $query = "SELECT bb.*, b.title 
              FROM borrowed_books bb 
              JOIN books b ON bb.book_id = b.id 
              ORDER BY bb.created_at DESC 
              LIMIT 10";
    
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $activities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode(['success' => true, 'activities' => $activities]);
}
?>