<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

require_once __DIR__ . '/../../src/config.php';
$conn = (new Database())->getConnection();

$book_id = $_POST['book_id'];
$student_name = $_POST['student_name'];
$student_id = $_POST['student_id'];
$borrow_date = $_POST['borrow_date'];
$return_date = $_POST['return_date'];

// Check if book is available
$check = $conn->prepare("SELECT available FROM books WHERE id = ?");
$check->execute([$book_id]);
$book = $check->fetch();

if($book['available'] <= 0) {
    $_SESSION['error'] = "Book not available!";
    header("Location: dashboard.php");
    exit();
}

// Insert borrow record
$stmt = $conn->prepare("INSERT INTO borrowed_books (book_id, student_name, student_id, borrow_date, return_date, status) 
                        VALUES (?, ?, ?, ?, ?, 'borrowed')");
$stmt->execute([$book_id, $student_name, $student_id, $borrow_date, $return_date]);

// Update book availability
$update = $conn->prepare("UPDATE books SET available = available - 1 WHERE id = ?");
$update->execute([$book_id]);

$_SESSION['success'] = "Book borrowed successfully!";
header("Location: dashboard.php");
exit();
?>