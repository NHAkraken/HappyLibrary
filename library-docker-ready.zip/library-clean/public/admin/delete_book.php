<?php
session_start();

if(!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit();
}

$id = isset($_GET['id']) ? $_GET['id'] : 0;

include_once(__DIR__ . '/../../src/config.php');

$database = new Database();
$conn = $database->getConnection();

// Get image filename
$stmt = $conn->prepare("SELECT image FROM books WHERE id = :id");
$stmt->bindParam(':id', $id);
$stmt->execute();
$book = $stmt->fetch(PDO::FETCH_ASSOC);

// Delete from database
$stmt = $conn->prepare("DELETE FROM books WHERE id = :id");
$stmt->bindParam(':id', $id);

if($stmt->execute()) {
    // Delete image file
    if($book && $book['image'] && $book['image'] != 'default.jpg') {
        $image_path = "../images/books/" . $book['image'];
        if(file_exists($image_path)) {
            unlink($image_path);
        }
    }
    
    echo "<script>
            alert('Book deleted successfully!');
            window.location.href='dashboard.php';
          </script>";
} else {
    echo "<script>
            alert('Could not delete book!');
            window.location.href='dashboard.php';
          </script>";
}
?>